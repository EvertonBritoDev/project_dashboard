# Getting Started

Clone the repository and install dependencies:

```git
git clone https://github.com/your-username/your-repo-name.git
cd your-repo-name
npm install
# or
yarn install
```

# Running the App

Start the development server:

```git
npm run dev
# or
yarn dev
```

# Building for Production

Start the development server:

```git
npm run build
# or
yarn build
```
