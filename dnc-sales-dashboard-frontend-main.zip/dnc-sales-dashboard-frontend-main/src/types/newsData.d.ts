export interface NewsData {
  title: string
  date: string
  link: string
}
