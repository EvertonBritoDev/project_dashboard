export interface StarsData {
  name: string
  value: number
}
