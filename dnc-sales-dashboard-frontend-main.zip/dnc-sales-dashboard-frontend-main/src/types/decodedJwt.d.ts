export interface DecodedJWT {
  userId: number
  iat: number
  exp: number
}
