export interface TypographiesProps {
  color?: string
  size?: number
  lineheight?: number
  weight?: number
}
