export interface HighlightsData {
  value: number
  subtitle: string
}
