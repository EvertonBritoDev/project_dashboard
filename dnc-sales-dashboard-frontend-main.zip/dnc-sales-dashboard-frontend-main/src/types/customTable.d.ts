export interface CustomTableProps {
  headers: string[]
  rows: React.ReactNode[][]
}
