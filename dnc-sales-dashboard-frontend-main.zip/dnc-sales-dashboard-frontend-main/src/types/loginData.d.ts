export interface LoginData {
  jwt_token: string
}

export interface LoginPostData {
  email: string
  password: string
}
