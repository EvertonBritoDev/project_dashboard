export interface AppThemeContextProps {
  appTheme: string
  toggleTheme: () => void
}
