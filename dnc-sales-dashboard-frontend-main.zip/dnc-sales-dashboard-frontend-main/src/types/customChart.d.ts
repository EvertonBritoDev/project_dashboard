export interface CustomChartProps {
  labels: string[]
  data: number[]
  type: 'line' | 'bar'
}
